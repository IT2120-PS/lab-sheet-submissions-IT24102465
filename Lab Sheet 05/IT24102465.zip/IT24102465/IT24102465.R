setwd("C:\\Users\\IT24102465\\Desktop\\IT24102465")
#1
Delivery_Times<-read.table("Exercise - Lab 05.txt",header = TRUE,sep = ",")
fix(Delivery_Times)
attach(Delivery_Times)
#2
histogram <- hist(Delivery_Times$Delivery_Time, 
                  main = "Histogram for Delivery Times using Nine Class Intervals", 
                  xlab = "Delivery Time (minutes)", 
                  ylab = "Frequency", 
                  breaks = seq(20, 70, length.out = 10),  # 9 intervals from 20 to 70
                  right = TRUE)
#3
#observation: The distribution appears to be skewed to the right (positively skewed)

#4
cumulative_freq <- cumsum(histogram$counts)


plot(histogram$mids, cumulative_freq, 
     type = "o",  # "o" stands for overplotted points with lines
     main = "Cumulative Frequency Polygon (Ogive)", 
     xlab = "Delivery Time (minutes)", 
     ylab = "Cumulative Frequency",
     pch = 16)

