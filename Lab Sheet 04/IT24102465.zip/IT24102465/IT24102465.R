setwd("C:\\Users\\IT24102465\\Desktop\\IT24102465")
branch_data<-read.table("DATA 4.txt", header = TRUE,sep = " ")
fix(branch_data)
attach(branch_data)
str(branch_data)
boxplot(X1,main="Box plot for sales",outline = TRUE,outpch=8,horizontal = TRUE)
boxplot(X1,main="Box plot for interpret",outline = TRUE,outpch=8,horizontal = TRUE)
boxplot(X1,main="Box plot for shape",outline = TRUE,outpch=8,horizontal = TRUE)
summary(X1)
summary(X2)
summary(X3)

quantile(X1)
quantile(X1)[2]
quantile(X1)[4]

IQR(X1)
IQR(X2)
IQR(X3)

get.outliers<-function(z){
  q1<-quantile(z)[2]
  q3<-quantile(z)[4]
  iqr<-q3-q1
  
  ub<-q3+1.5*iqr
  lb<-q1-1.5*iqr
  
  print(paste("Upper Bound= ",ub))
  print(paste("Lower Bound= ",lb))
  print(paste("Outliers: ", paste(sort(z[z<lb | z>ub]),collapse = ",")))
  
}

get.outliers(X1)
get.outliers(X2)
get.outliers(X3)


