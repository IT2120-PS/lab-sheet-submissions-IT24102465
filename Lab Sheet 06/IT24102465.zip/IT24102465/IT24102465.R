setwd("C:\\Users\\OSHADHA\\Desktop\\It24102465")

#Exercise
##Question 01
#Part 1
#Binomial Distribution

#Part 2
1-pbinom(46,50,0.85,lower.tail = TRUE)
pbinom(46,50,0.85,lower.tail = FALSE)

##Question 02
#Part 1
#Number of calls per an hour

#Part 2
#Poisson Distribution

#Part 3
dpois(15,12)