setwd("C:\\Users\\OSHADHA\\Desktop\\IT24102465")

#Exercise
#i
y<-rnorm(25,mean = 45,sd=2)

#ii
t.test(y,mu=46,alternative = "less")
